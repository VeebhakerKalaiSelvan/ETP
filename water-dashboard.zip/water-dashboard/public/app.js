const firebaseConfig = {
  apiKey: "AIzaSyC0NhjThym1si7IoGef3Qv493R649N136A",
  authDomain: "clean-water-f7955.firebaseapp.com",
  databaseURL: "https://clean-water-f7955-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "clean-water-f7955",
  storageBucket: "clean-water-f7955.firebasestorage.app",
  messagingSenderId: "643684959346",
  appId: "1:643684959346:web:f3a9b10d3bd8fb54912eeb",
  measurementId: "G-GXX3T7X875"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

let currentChart = null;

document.getElementById('csvFile').addEventListener('change', function (e) {
  const file = e.target.files[0];
  if (!file) return;

  Papa.parse(file, {
    header: true,
    skipEmptyLines: true,
    complete: function (results) {
      const labels = [], turb = [], tds = [], ph = [], timestamps = [];

      results.data.forEach((row, index) => {
        const timestamp = row.timestamp;
        const turbidity = parseFloat(row.turbidity_raw);
        const tdsValue = parseFloat(row.tds_raw);
        const phValue = parseFloat(row.ph_raw);

        if (!isNaN(turbidity) && !isNaN(tdsValue) && !isNaN(phValue)) {
          labels.push(timestamp);
          timestamps.push(timestamp);
          turb.push(turbidity);
          tds.push(tdsValue);
          ph.push(phValue);

          // Optional: Save to Firebase
          db.ref('readings/' + index).set({ timestamp, turbidity, tds: tdsValue, ph: phValue });
        }
      });

      drawChart(labels, turb, tds, ph);
      showStats(turb, tds, ph, timestamps);

      // ✅ Reset file input so same file can be uploaded again
      document.getElementById('csvFile').value = '';
    }
  });
});

function drawChart(labels, turb, tds, ph) {
  if (currentChart) {
    currentChart.destroy(); // ✅ Clear previous chart before creating new one
  }

  currentChart = new Chart(document.getElementById("chart"), {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        { label: 'Turbidity', data: turb, borderColor: 'blue', yAxisID: 'y1' },
        { label: 'TDS', data: tds, borderColor: 'green', yAxisID: 'y2' },
        { label: 'pH', data: ph, borderColor: 'orange', yAxisID: 'y3' }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y1: { beginAtZero: true, position: 'left', title: { display: true, text: 'Turbidity' }},
        y2: { beginAtZero: true, position: 'right', title: { display: true, text: 'TDS' }},
        y3: { beginAtZero: true, position: 'right', offset: true, title: { display: true, text: 'pH' }}
      }
    }
  });
}

function showStats(turb, tds, ph, timestamps) {
  const avg = arr => (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2);
  const max = arr => Math.max(...arr);
  const min = arr => Math.min(...arr);

  const turbAvg = parseFloat(avg(turb));
  const tdsAvg = parseFloat(avg(tds));
  const phAvg = parseFloat(avg(ph));

  const maxTurb = max(turb);
  const worstIndex = turb.indexOf(maxTurb);
  const worstDate = timestamps[worstIndex];

  let status = "", tip = "";

  if (turbAvg < 50 && tdsAvg < 500 && phAvg >= 6.5 && phAvg <= 8.5) {
    status = "✅ Water quality is GOOD.";
    tip = "No major action needed. Keep monitoring.";
  } else if (turbAvg < 100 && tdsAvg < 800) {
    status = "⚠️ Water is MODERATE. Caution advised.";
    tip = "Consider checking filters and UV sterilizer.";
  } else {
    status = "❌ Water is likely UNSAFE.";
    tip = "Immediate action required: recheck filters, test source, and treat water.";
  }

  document.getElementById("analysis").innerHTML = `
    <h3>📊 Summary</h3>
    <b>Turbidity:</b> Avg ${avg(turb)}, Min ${min(turb)}, Max ${maxTurb}<br>
    <b>TDS:</b> Avg ${avg(tds)}, Min ${min(tds)}, Max ${max(tds)}<br>
    <b>pH:</b> Avg ${avg(ph)}, Min ${min(ph)}, Max ${max(ph)}<br><br>
    🗓️ <b>Worst Reading Day (highest turbidity):</b> ${worstDate}<br><br>
    ${status}<br>
    💡 <b>Suggestion:</b> ${tip}
  `;
}
