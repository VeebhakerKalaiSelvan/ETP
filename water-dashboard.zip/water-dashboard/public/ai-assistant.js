async function askAI() {
  const input = document.getElementById("user-input").value;
  const output = document.getElementById("response-output");

  output.textContent = "Thinking...";

  try {
    const res = await fetch("https://<YOUR_FIREBASE_FUNCTION_URL>", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: input })
    });

    const data = await res.json();
    output.textContent = data.response || "No reply.";
  } catch (err) {
    output.textContent = "❌ Error: " + err.message;
  }
}
