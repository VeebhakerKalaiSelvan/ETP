const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const fetch = require("node-fetch"); // Required for HTTP requests

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// POST endpoint to interact with your local AI (LM Studio)
app.post("/ask", async (req, res) => {
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  try {
    const response = await fetch("http://localhost:1234/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gemma:3-12b-instruct-q3_k_l",
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant. Keep all responses short and simple, ideally under 3 sentences."
          },
          {
            role: "user",
            content: message
          }
        ],
        temperature: 0.5,
        stream: false
      }),
    });

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || "Sorry, I couldn't generate a response.";

    res.json({ reply });
  } catch (err) {
    console.error("❌ AI Server Error:", err.message);
    res.status(500).json({ error: "AI server error. Make sure LM Studio is running." });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ AI proxy server running at http://localhost:${PORT}`);
});
